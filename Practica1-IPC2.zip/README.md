# Practica1-IPC2
Repositorio de prueba IPC2

Primer archivo para este repositorio
visita mi perfil [Alex Santos](https://github.com/alexsan-dev/)
